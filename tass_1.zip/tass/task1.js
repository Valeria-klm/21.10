const averageGrade = 85; // Змініть значення для перевірки різних результатів

if (averageGrade < 60) {
    console.log("Незадовільно");
} else if (averageGrade <= 70) {
    console.log("Задовільно");
} else if (averageGrade <= 80) {
    console.log("Добре");
} else if (averageGrade <= 90) {
    console.log("Дуже добре");
} else if (averageGrade <= 100) {
    console.log("Відмінно");
} else {
    console.log("Помилка: середня оцінка повинна бути в діапазоні від 0 до 100");
}
