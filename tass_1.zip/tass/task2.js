const averageGrade = 85; // Змініть значення для перевірки різних результатів
const gradeCategory = Math.floor(averageGrade / 10);

switch (gradeCategory) {
    case 10:
    case 9:
        console.log("Відмінно");
        break;
    case 8:
        console.log("Дуже добре");
        break;
    case 7:
        console.log("Добре");
        break;
    case 6:
        console.log("Задовільно");
        break;
    case 5:
    case 4:
    case 3:
    case 2:
    case 1:
    case 0:
        console.log("Незадовільно");
        break;
    default:
        console.log("Помилка: середня оцінка повинна бути в діапазоні від 0 до 100");
}
